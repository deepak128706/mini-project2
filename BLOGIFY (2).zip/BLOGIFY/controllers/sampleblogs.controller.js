// Import necessary services and helpers
const { sampleBlogsService } = require("../services");
const bcrypt = require("bcrypt");
const { tokenHelper } = require("../helper");

module.exports = {
    // De a controller method to render the sampleblogs page
    getSampleBlogsPage: async (req, res, next) => {
        try {
            // Assuming you have methods to fetch blogs and magazines data
            const blogs = await fetchBlogs();
            // const magazines = await fetchMagazines();
            res.render("sampleblogs", { blogs });
        } catch (error) {
            next(error); // Pass the error to the error handling middleware
        }
    },
    // Define other controller methods as needed...
}
 