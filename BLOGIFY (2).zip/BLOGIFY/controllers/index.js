const blogController = require("./blog.controller");
const userController = require("./user.controller");
const sampleblogsController = require("./sampleblogs.controller");
const aboutController = require("./about.controller")

module.exports = {
    blogController,
    userController,
    sampleblogsController,
    aboutController
}